import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class Main {
    public static void main(String[] args){
        //著作権表示
        System.out.println("Rezi System [Version 1.5.0]");
        System.out.println("(c) @KAKIMOTI1230 .All rights reserved");
        System.out.println("");
        
        //時間取得
        LocalDateTime zikan = LocalDateTime.now();
        //時間フォーマット指定
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
System.out.println(zikan.format(dtf));

        //来客者数カウンター(1会計=1人)
        int raikyaku = 0;
        //データチェック配列(データが存在するかどうか識別、デフォルトはfalse)
        boolean[] hantei = new boolean[8];
        //アレイリスト宣言
        ArrayList<Item> items = new ArrayList<>();//商品リスト
        ArrayList<SellTime> st = new ArrayList<>();//売上時間リスト
        //ファイル読み込み
        String data;
        int count = 0;
        String[] temps = new String[4]; 
        try(BufferedReader br = new BufferedReader(new FileReader("input.txt"))){
            while((data = br.readLine()) != null){
                temps = data.split(",");
                //商品インスタンス生成
                Item item = new Item(Integer.parseInt(temps[0]),temps[1],Integer.parseInt(temps[2]),Integer.parseInt(temps[3]));
                items.add(item);//アレーリストに追加
                hantei[count] = true;
                count++;
            }
            //登録商品初回表示
            System.out.println("商品データ読み込み成功、データを登録しました");
            for(Item i : items){
                System.out.println(i.toString());
            }
            System.out.println("");

            //モード選択
            Scanner sc = new Scanner(System.in);
            System.out.println("*** モード選択 ***");
            System.out.println("0:レジ 1:売上記録 2:商品データ 9:システム終了");
            System.out.print("整数を入力してください ==>");
            int input = Integer.parseInt(sc.nextLine());
            while(input != 9){
                //レジシステム
                if(input == 0){
                    String input2 = "0";
                    int sumPrice = 0; //レジ時合計金額、初期化
                    System.out.println("");
                    System.out.println("*** レジシステム ***");
                    System.out.print("バーコードをスキャン ==>");
                    input2 = sc.nextLine();
                    while(input2 != ""){  //何も入力されない場合はレジシステムを終了する
                        boolean[] hit = new boolean[9];//hitしたかどうか
                        int[] sellCount = new int[9];//売れた回数
                        boolean teisei = true;//訂正フラグ、falseで訂正モード
                        ArrayList<Integer> kaikei = new ArrayList<>();//売上の一時保管
                        while(input2 != ""){
                            //Main.codeRead(input2);
                            switch(input2){
                                case "11111111111113":
                                        if(hantei[0] == true){
                                            System.out.println(items.get(0).getName() +":"+ items.get(0).getPrice() + "円");
                                            System.out.println("");
                                            kaikei.add(0);
                                        /*    hit[0] = true;
                                            sellCount[0] += 1;
                                            items.get(0).setCount(1);//販売数+1
                                            items.get(0).setZaiko(-1);//在庫-1
                                            sumPrice += items.get(0).getPrice();//会計時合計金額に加算
        
                                            SellTime selltime = new SellTime(zikan.format(dtf),items.get(0).getName()); //売上時間のインスタンス生成
                                            st.add(selltime);//売上時間のリストに追加
                                            */
                                        } else {
                                            System.out.println("このバーコードは登録されていません");
                                        }
                                break;

                                case "22222222222226":
                                    if(hantei[1] == true){
                                        System.out.println(items.get(1).getName() +":"+ items.get(1).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(1);

                                    /*    hit[1] = true;
                                        sellCount[1] += 1;
                                        items.get(1).setCount(1);//販売数+1
                                        items.get(1).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(1).getPrice();//会計時合計金額に加算 
                                    
                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(1).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加
                                    
                                        System.out.println(items.get(1).getName() +":"+ items.get(1).getPrice() + "円");
                                        System.out.println("");*/
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "33333333333339":
                                    if(hantei[2] == true){
                                        System.out.println(items.get(2).getName() +":"+ items.get(2).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(2);
                                    /*    hit[2] = true;
                                        sellCount[2] += 1;
                                        items.get(2).setCount(1);//販売数+1
                                        items.get(2).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(2).getPrice();//会計時合計金額に加算 
                                    
                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(2).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加
                                    
                                        System.out.println(items.get(2).getName() +":"+ items.get(2).getPrice() + "円");
                                        System.out.println("");
                                        */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "44444444444442":
                                    if(hantei[3] == true){
                                        System.out.println(items.get(3).getName() +":"+ items.get(3).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(3);
                    /*    hit[3] = true;
                                        sellCount[3] += 1;
                                        items.get(3).setCount(1);//販売数+1
                                        items.get(3).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(3).getPrice();//会計時合計金額に加算 
                                    
                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(3).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加

                                        System.out.println(items.get(3).getName() +":"+ items.get(3).getPrice() + "円");
                                        System.out.println("");
                                    */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "55555555555555":
                                    if(hantei[4] == true){
                                        System.out.println(items.get(4).getName() +":"+ items.get(4).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(4);

                                    /*    hit[4] = true;
                                        sellCount[4] += 1;
                                        items.get(4).setCount(1);//販売数+1
                                        items.get(4).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(4).getPrice();//会計時合計金額に加算

                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(4).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加

                                        System.out.println(items.get(4).getName() +":"+ items.get(4).getPrice() + "円");
                                        System.out.println("");
                                    */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "66666666666668":
                                    if(hantei[5] == true){
                                        System.out.println(items.get(5).getName() +":"+ items.get(5).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(5);

                                    /*    hit[5] = true;
                                        sellCount[5] += 1;
                                        items.get(5).setCount(1);//販売数+1
                                        items.get(5).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(5).getPrice();//会計時合計金額に加算 

                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(5).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加

                                        System.out.println(items.get(5).getName() +":"+ items.get(5).getPrice() + "円");
                                        System.out.println("");
                                    */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "77777777777771":
                                    if(hantei[6] == true){
                                        System.out.println(items.get(6).getName() +":"+ items.get(6).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(6);

                                /*        hit[6] = true;
                                        sellCount[6] += 1;
                                        items.get(6).setCount(1);//販売数+1
                                        items.get(6).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(6).getPrice();//会計時合計金額に加算

                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(6).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加

                                        System.out.println(items.get(6).getName() +":"+ items.get(6).getPrice() + "円");
                                        System.out.println("");
                                */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "88888888888884":
                                    if(hantei[7] == true){
                                        System.out.println(items.get(7).getName() +":"+ items.get(7).getPrice() + "円");
                                        System.out.println("");
                                        kaikei.add(7);
                                    /*    hit[7] = true;
                                        sellCount[7] += 1;
                                        items.get(7).setCount(1);//販売数+1
                                        items.get(7).setZaiko(-1);//在庫-1
                                        sumPrice += items.get(7).getPrice();//会計時合計金額に加算 

                                        SellTime selltime = new SellTime(zikan.format(dtf),items.get(7).getName()); //売上時間のインスタンス生成
                                        st.add(selltime);//売上時間のリストに追加

                                        System.out.println(items.get(7).getName() +":"+ items.get(7).getPrice() + "円");
                                        System.out.println("");
                                    */
                                    } else {
                                        System.out.println("このバーコードは登録されていません");
                                    }
                                break;

                                case "99999999999997"://間違えたときの訂正コード
                                    System.out.println("訂正モード");
                                    System.out.println("間違えたコードを入力してください");
                                    teisei = false;
                                break;

                                default:
                                System.out.println("このバーコードは登録されていません");
                            }
                            System.out.print("バーコードをスキャン ==>");
                            input2 = sc.nextLine();        
                        }
for(int ct : kaikei){
    System.out.println(ct);
}
                        //売上確認表示
                        raikyaku++;//来客者数+1
                        int j = 0;
                        for(Item i : items){
                            if(hit[j] == true){//一個も売れてない物は出力しない
                                System.out.println(i.getName() +":"+ sellCount[j] +"個、計" + sellCount[j] * i.getPrice() +"円");
                            }
                            j++;
                        }
                        System.out.println("合計金額:"+ sumPrice + "円");

                        sumPrice = 0; //レジ時合計金額、初期化  
                        System.out.println("");
                        System.out.println("終了する際はもう一度エンターを押してください");
                        System.out.print("バーコードをスキャン ==>");
                        input2 = sc.nextLine();        
                    }

                //売上記録確認(現バージョンでは一度プログラムを終了するとリセットされる)
                } else if(input == 1){
                    System.out.println("                ***** 売上記録 *****");
                    int allSumPrice = 0;
                    System.out.println("+----------------------------------+----------+----------+");
                    System.out.println("|  商  品  名                      | 販売個数 | 売上金額 |");
                    System.out.println("+----------------------------------+----------+----------+");
                    int j=0;

                    for(Item i : items){
                        String space = "";
                        for(int k=0; k < (13 - items.get(j).getName().length()); k++){
                            space = space + " ";
                        }

                        allSumPrice = allSumPrice + (i.getPrice() * i.getCount());
                       // System.out.println(i.getName() + ":" + i.getCount() +"ヶ販売,売上金額:"+ i.getPrice() * i.getCount() +"円");
                        System.out.printf("| %-20s%s|   %2d個   | %5d円  |\n", i.getName(), space, i.getCount(), i.getPrice() * i.getCount());
                        System.out.println("+----------------------------------+----------+----------+");
                        j++;
                    }
                    System.out.println("");
                    System.out.println("売上合計:" + allSumPrice + "円");
                    System.out.println("来客数:" + raikyaku + "人");

                    for(SellTime s : st){
                        System.out.println(s.toString());
                    }



                } else if(input == 2){//商品データ一覧
                    int j = 0;
                    System.out.println("                ***** 商品データ *****");
                    System.out.println("+----+----------------------------------+--------+-------+");
                    System.out.println("| ID |  商  品  名                      | 価 格  | 在 庫 |");
                    System.out.println("+----+----------------------------------+--------+-------+");
                    for(Item i : items){
                        String space = "";
                        for(int k=0; k < (13 - items.get(j).getName().length()); k++){
                            space = space + " ";
                        }
//System.out.println(items.get(j).getName().length());
                        System.out.printf("| %2d | %-20s%s| %4d円 | %3d個 |\n", i.getId(), i.getName(),space , i.getPrice(), i.getZaiko());
                        System.out.println("+----+----------------------------------+--------+-------+");
                        j++;
                    }
                } else {
                    System.out.println("その番号は登録されてません");
            }
                //再度モード選択
                System.out.println("");
                System.out.println("*** モード選択 ***");
                System.out.println("0:レジ 1:売上記録 2:商品データ 9:システム終了");
                System.out.print("整数を入力してください ==>");
                input = Integer.parseInt(sc.nextLine());
            }
            //9が入力、プログラム終了
            System.out.println("お疲れさまでした、プログラムを終了します。");

        //エラー発生時の処理
        } catch(NumberFormatException e){//整数以外のデータ
            System.out.println("整数以外のデータが入力されています");
        } catch(FileNotFoundException e){//入力ファイルが見つからない
            System.out.println(e.getMessage());
        } catch(IOException e){//ファイルはあるが読み込めない
            System.out.println(e.getMessage());
        } finally {
            //売上記録をファイル出力する
            try(BufferedWriter bw = new BufferedWriter(new FileWriter("Result.txt"))){
                int allSumPrice = 0; //全売上金額
                bw.write("*** 売上記録 ***");
                bw.newLine();
                for(Item i : items){
                    allSumPrice = allSumPrice + (i.getPrice() * i.getCount());
                    bw.write(i.getName() +":"+ i.getCount() +"ヶ販売,売上金額:"+ i.getPrice() * i.getCount() +"円");
                    bw.newLine();
                }
                bw.write("売上合計:" + allSumPrice + "円");
                bw.newLine();
                bw.write("来客数:" + raikyaku + "人");
                bw.newLine();

                try(BufferedWriter tl = new BufferedWriter(new FileWriter("TimeLog.txt"))){
                    for(SellTime s : st){
                        tl.write(s.toString());
                        tl.newLine();
                    }       
                }
            
            } catch(NumberFormatException e){
                System.out.println("エラー:整数を入力してください");
            } catch(IOException e){
                System.out.println("エラー:ファイル入出力エラー");
            } finally {
                System.out.println("レジシステムを終了します");
            }   
        }
    }
}